import java.sql.*;
import java.util.*;

public class SQLLoader {
    private final String connectionUrl = "jdbc:sqlserver://localhost:1433;databaseName=C45_Ejemplo;encrypt=true;trustServerCertificate=true";
    private final String user = "usuario_c45";
    private final String password = "1234";

    // Cargar datos desde la tabla (omitiendo columna Id)
    public List<Map<String, String>> cargarDatos(String tabla) {
        List<Map<String, String>> datos = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(connectionUrl, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM " + tabla)) {

            ResultSetMetaData metaData = rs.getMetaData();
            int numCols = metaData.getColumnCount();

            while (rs.next()) {
                Map<String, String> fila = new HashMap<>();
                for (int i = 1; i <= numCols; i++) {
                    String col = metaData.getColumnName(i);
                    String val = rs.getString(i);

                    // Excluir columna 'Id'
                    if (!col.equalsIgnoreCase("Id")) {
                        fila.put(col, val);
                    }
                }
                datos.add(fila);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return datos;
    }

    // Obtener solo los atributos útiles (sin la clase y sin Id)
    public List<String> obtenerAtributos(String tabla, String columnaClase) {
        List<String> atributos = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(connectionUrl, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT TOP 1 * FROM " + tabla)) {

            ResultSetMetaData metaData = rs.getMetaData();
            int numCols = metaData.getColumnCount();

            for (int i = 1; i <= numCols; i++) {
                String col = metaData.getColumnName(i);
                if (!col.equalsIgnoreCase("Id") && !col.equalsIgnoreCase(columnaClase)) {
                    atributos.add(col);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return atributos;
    }
}
