import javax.swing.*;
import java.awt.*;

public class TreeVisualizer extends JPanel {
    private final TreeNode root;
    private final int nodeWidth = 120;
    private final int nodeHeight = 40;
    private final int vSpacing = 60;
    private final int hSpacing = 30;

    public TreeVisualizer(TreeNode root) {
        this.root = root;
        setPreferredSize(new Dimension(1000, 800));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        drawTree(g, root, getWidth() / 2, 40, getWidth() / 4);
    }

    private void drawTree(Graphics g, TreeNode node, int x, int y, int offset) {
        if (node == null) return;

        String label = node.isLeaf() ? "Clase: " + node.label : node.attribute + " ≤ " + String.format("%.2f", node.threshold);

        g.setColor(Color.BLACK);
        g.drawRect(x - nodeWidth / 2, y, nodeWidth, nodeHeight);
        g.drawString(label, x - nodeWidth / 2 + 10, y + 25);

        if (!node.isLeaf()) {
            int childY = y + vSpacing;

            if (node.left != null) {
                int leftX = x - offset;
                g.drawLine(x, y + nodeHeight, leftX, childY);
                drawTree(g, node.left, leftX, childY, offset / 2);
                g.drawString("Sí", (x + leftX) / 2 - 10, (y + childY) / 2);
            }

            if (node.right != null) {
                int rightX = x + offset;
                g.drawLine(x, y + nodeHeight, rightX, childY);
                drawTree(g, node.right, rightX, childY, offset / 2);
                g.drawString("No", (x + rightX) / 2 + 10, (y + childY) / 2);
            }
        }
    }

    public static void mostrar(TreeNode root) {
        JFrame frame = new JFrame("Árbol de Decisión");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.add(new JScrollPane(new TreeVisualizer(root)));
        frame.pack();
        frame.setVisible(true);
    }
}
