import java.util.*;

public class Main {
    public static void main(String[] args) {
        SQLLoader loader = new SQLLoader();
        String tabla = "PacientesCardiacos";
        String clase = "RiesgoCardiaco";

        List<Map<String, String>> datos = loader.cargarDatos(tabla);
        List<String> atributos = loader.obtenerAtributos(tabla, clase);

        if (datos.isEmpty()) {
            System.out.println("❌ No se cargaron datos desde la base de datos.");
            return;
        }

        C45DecisionTree arbol = new C45DecisionTree();
        arbol.train(datos, atributos, clase);

        // Mostrar árbol en consola
        System.out.println("Árbol generado:");
        arbol.printTree();

        // Mostrar ventana gráfica del árbol
        TreeVisualizer.mostrar(arbol.getRoot());

        // Prueba de predicción
        Map<String, String> nuevoEjemplo = Map.of(
                "Outlook", "2",
                "Temperature", "72",
                "Humidity", "85"
        );

        String resultado = arbol.predict(nuevoEjemplo);
        System.out.println("Predicción: " + resultado);
    }
}
