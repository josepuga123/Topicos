import java.util.*;

public class Main {
    public static void main(String[] args) {
        SQLLoader loader = new SQLLoader();
        String tabla = "CancerData";
        String clase = "Diagnosis";

        List<Map<String, String>> datos = loader.cargarDatos(tabla);
        List<String> atributos = loader.obtenerAtributos(tabla, clase);

        if (datos.isEmpty()) {
            System.out.println("❌ No se cargaron datos desde la base de datos.");
            return;
        }

        C45DecisionTree arbol = new C45DecisionTree();
        arbol.train(datos, atributos, clase);
        System.out.println("Árbol generado:");
        arbol.printTree();

        TreeVisualizer.show(arbol.getRoot());

        Map<String, String> nuevoEjemplo = Map.of(
                "Sexo", "F",
                "Edad", "55",
                "FamilyHistory", "Yes",
                "TumorSize", "2.5",
                "Histology", "Ductal",
                "Menopause", "Yes",
                "Smoking", "No",
                "AlcoholConsumption", "Yes",
                "HormoneTherapy", "Yes",
                "BMI", "26.5"
        );

        String resultado = arbol.predict(nuevoEjemplo);
        System.out.println("Predicción para el nuevo ejemplo: " + resultado);
    }
}