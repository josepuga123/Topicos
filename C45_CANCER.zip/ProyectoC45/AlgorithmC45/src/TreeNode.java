import java.util.*;

public class TreeNode {
    String attribute;
    Double threshold;
    String thresholdCategory;
    String label;
    TreeNode left;
    TreeNode right;
    double probability; // Probability of the majority class
    Map<String, Integer> distribution; // Class distribution at the leaf

    public TreeNode() {
    }

    public TreeNode(String label) {
        this.label = label;
    }

    public boolean isLeaf() {
        return label != null;
    }
}