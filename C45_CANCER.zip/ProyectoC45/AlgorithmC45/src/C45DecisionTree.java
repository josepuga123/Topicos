import java.util.*;

public class C45DecisionTree {
    private TreeNode root;
    private final List<String> atributosCategoricos = Arrays.asList("Sexo", "Histology", "FamilyHistory", "Menopause", "Smoking", "AlcoholConsumption", "HormoneTherapy");

    public void train(List<Map<String, String>> data, List<String> attributes, String target) {
        root = buildTree(data, new ArrayList<>(attributes), target);
    }

    public String predict(Map<String, String> instance) {
        TreeNode node = root;
        while (!node.isLeaf()) {
            String attrValue = instance.get(node.attribute);
            if (attrValue == null) {
                return "❌ Valor faltante para: " + node.attribute;
            }

            if (atributosCategoricos.contains(node.attribute)) {
                boolean matches = attrValue.equals(node.thresholdCategory);
                node = matches ? node.left : node.right;
            } else {
                try {
                    double val = Double.parseDouble(attrValue);
                    node = (val <= node.threshold) ? node.left : node.right;
                } catch (NumberFormatException e) {
                    return "❌ Valor no numérico para: " + node.attribute;
                }
            }
            if (node == null) {
                return "❌ Ruta no encontrada en el árbol";
            }
        }
        return node.label + " (Probability: " + String.format("%.2f%%", node.probability * 100) + ")";
    }

    private TreeNode buildTree(List<Map<String, String>> data, List<String> attributes, String target) {
        if (data.isEmpty()) {
            TreeNode node = new TreeNode("Sin datos");
            node.distribution = new HashMap<>(); // Initialize empty distribution
            node.probability = 0.0;
            return node;
        }

        if (allSameClass(data, target)) {
            TreeNode node = new TreeNode(data.get(0).get(target));
            node.probability = 1.0;
            node.distribution = calculateClassDistribution(data, target);
            return node;
        }

        if (attributes.isEmpty()) {
            String majority = majorityClass(data, target);
            TreeNode node = new TreeNode(majority);
            node.distribution = calculateClassDistribution(data, target);
            node.probability = node.distribution.getOrDefault(majority, 0) / (double) data.size();
            return node;
        }

        String bestAttr = null;
        double bestGainRatio = -Double.MAX_VALUE;
        double bestThreshold = 0.0;
        String bestThresholdCategory = null;

        for (String attr : attributes) {
            if (atributosCategoricos.contains(attr)) {
                Object[] result = gainRatioCategorico(data, attr, target);
                double gainRatio = (double) result[0];
                if (gainRatio > bestGainRatio) {
                    bestGainRatio = gainRatio;
                    bestAttr = attr;
                    bestThresholdCategory = (String) result[1];
                }
            } else {
                double[] result = gainRatioNumerico(data, attr, target);
                if (result[0] > bestGainRatio) {
                    bestGainRatio = result[0];
                    bestAttr = attr;
                    bestThreshold = result[1];
                }
            }
        }

        if (bestAttr == null || bestGainRatio <= 0) {
            String majority = majorityClass(data, target);
            TreeNode node = new TreeNode(majority);
            node.distribution = calculateClassDistribution(data, target);
            node.probability = node.distribution.getOrDefault(majority, 0) / (double) data.size();
            return node;
        }

        TreeNode node = new TreeNode();
        node.attribute = bestAttr;

        if (atributosCategoricos.contains(bestAttr)) {
            node.thresholdCategory = bestThresholdCategory;
        } else {
            node.threshold = bestThreshold;
        }

        List<Map<String, String>> left = new ArrayList<>();
        List<Map<String, String>> right = new ArrayList<>();

        for (Map<String, String> row : data) {
            String value = row.get(bestAttr);

            if (atributosCategoricos.contains(bestAttr)) {
                if (value != null && value.equals(bestThresholdCategory)) {
                    left.add(row);
                } else {
                    right.add(row);
                }
            } else {
                try {
                    double val = Double.parseDouble(value);
                    if (val <= bestThreshold) left.add(row);
                    else right.add(row);
                } catch (NumberFormatException e) {
                    right.add(row);
                }
            }
        }

        List<String> newAttrs = new ArrayList<>(attributes);
        newAttrs.remove(bestAttr);

        node.left = (left.size() < 5) ? createLeaf(data, target) : buildTree(left, newAttrs, target);
        node.right = (right.size() < 5) ? createLeaf(data, target) : buildTree(right, newAttrs, target);

        return node;
    }

    private TreeNode createLeaf(List<Map<String, String>> data, String target) {
        String majority = majorityClass(data, target);
        TreeNode node = new TreeNode(majority);
        node.distribution = calculateClassDistribution(data, target);
        node.probability = node.distribution.getOrDefault(majority, 0) / (double) data.size();
        return node;
    }

    private double[] gainRatioNumerico(List<Map<String, String>> data, String attr, String target) {
        List<Double> values = new ArrayList<>();
        for (Map<String, String> row : data) {
            String value = row.get(attr);
            if (value != null) {
                try {
                    values.add(Double.parseDouble(value));
                } catch (NumberFormatException e) {
                    // Skip invalid values
                }
            }
        }

        if (values.isEmpty()) return new double[]{-1, 0};

        Collections.sort(values);
        double bestThreshold = 0.0;
        double bestGainRatio = -1;

        for (int i = 1; i < values.size(); i++) {
            double threshold = (values.get(i - 1) + values.get(i)) / 2;

            List<Map<String, String>> left = new ArrayList<>();
            List<Map<String, String>> right = new ArrayList<>();

            for (Map<String, String> row : data) {
                String value = row.get(attr);
                if (value != null) {
                    try {
                        double val = Double.parseDouble(value);
                        if (val <= threshold) left.add(row);
                        else right.add(row);
                    } catch (NumberFormatException e) {
                        right.add(row);
                    }
                } else {
                    right.add(row);
                }
            }

            double infoGain = entropy(data, target)
                    - (left.size() / (double) data.size()) * entropy(left, target)
                    - (right.size() / (double) data.size()) * entropy(right, target);

            double splitInfo = 0;
            if (!left.isEmpty()) {
                double p = left.size() / (double) data.size();
                splitInfo -= p * Math.log(p) / Math.log(2);
            }
            if (!right.isEmpty()) {
                double p = right.size() / (double) data.size();
                splitInfo -= p * Math.log(p) / Math.log(2);
            }

            double ratio = (splitInfo == 0) ? 0 : infoGain / splitInfo;

            if (ratio > bestGainRatio && left.size() > 0 && right.size() > 0) {
                bestGainRatio = ratio;
                bestThreshold = threshold;
            }
        }

        return new double[]{bestGainRatio, bestThreshold};
    }

    private Object[] gainRatioCategorico(List<Map<String, String>> data, String attr, String target) {
        Map<String, List<Map<String, String>>> categories = new HashMap<>();
        for (Map<String, String> row : data) {
            String category = row.get(attr);
            if (category != null && !category.equals("null")) { // Exclude null as a category
                categories.computeIfAbsent(category, k -> new ArrayList<>()).add(row);
            }
        }

        if (categories.isEmpty()) return new Object[]{-1, null};

        double bestGainRatio = -1;
        String bestCategory = null;

        for (String category : categories.keySet()) {
            List<Map<String, String>> left = categories.get(category);
            List<Map<String, String>> right = new ArrayList<>();

            for (String otherCategory : categories.keySet()) {
                if (!otherCategory.equals(category)) {
                    right.addAll(categories.get(otherCategory));
                }
            }

            double infoGain = entropy(data, target)
                    - (left.size() / (double) data.size()) * entropy(left, target)
                    - (right.size() / (double) data.size()) * entropy(right, target);

            double splitInfo = 0;
            if (!left.isEmpty()) {
                double p = left.size() / (double) data.size();
                splitInfo -= p * Math.log(p) / Math.log(2);
            }
            if (!right.isEmpty()) {
                double p = right.size() / (double) data.size();
                splitInfo -= p * Math.log(p) / Math.log(2);
            }

            double ratio = (splitInfo == 0) ? 0 : infoGain / splitInfo;

            if (ratio > bestGainRatio && left.size() > 0 && right.size() > 0) {
                bestGainRatio = ratio;
                bestCategory = category;
            }
        }

        return new Object[]{bestGainRatio, bestCategory};
    }

    private boolean allSameClass(List<Map<String, String>> data, String target) {
        if (data.isEmpty()) return true;
        String label = data.get(0).get(target);
        for (Map<String, String> row : data) {
            if (!row.get(target).equals(label)) return false;
        }
        return true;
    }

    private String majorityClass(List<Map<String, String>> data, String target) {
        Map<String, Integer> count = new HashMap<>();
        for (Map<String, String> row : data) {
            String label = row.get(target);
            count.put(label, count.getOrDefault(label, 0) + 1);
        }
        return Collections.max(count.entrySet(), Map.Entry.comparingByValue()).getKey();
    }

    private Map<String, Integer> calculateClassDistribution(List<Map<String, String>> data, String target) {
        Map<String, Integer> count = new HashMap<>();
        for (Map<String, String> row : data) {
            String label = row.get(target);
            if (label != null) {
                count.put(label, count.getOrDefault(label, 0) + 1);
            }
        }
        return count;
    }

    private double entropy(List<Map<String, String>> data, String target) {
        Map<String, Integer> count = new HashMap<>();
        for (Map<String, String> row : data) {
            String label = row.get(target);
            if (label != null) {
                count.put(label, count.getOrDefault(label, 0) + 1);
            }
        }

        double entropy = 0.0;
        int total = data.size();
        if (total == 0) return 0.0;

        for (int c : count.values()) {
            double p = c / (double) total;
            entropy -= p * Math.log(p) / Math.log(2);
        }
        return entropy;
    }

    public void printTree() {
        printTreeRec(root, 0);
    }

    private void printTreeRec(TreeNode node, int nivel) {
        if (node == null) return;

        String indent = "  ".repeat(nivel);

        if (node.isLeaf()) {
            StringBuilder dist = new StringBuilder("{");
            if (node.distribution != null && !node.distribution.isEmpty()) {
                int total = node.distribution.values().stream().mapToInt(Integer::intValue).sum();
                for (Map.Entry<String, Integer> entry : node.distribution.entrySet()) {
                    double prob = entry.getValue() / (double) total;
                    dist.append(entry.getKey()).append(": ").append(String.format("%.2f%%", prob * 100)).append(", ");
                }
                if (dist.length() > 1) dist.setLength(dist.length() - 2);
            }
            dist.append("}");
            System.out.println(indent + "→ Clase: " + node.label + " (Probability: " + String.format("%.2f%%", node.probability * 100) + ", Distribution: " + dist + ")");
        } else {
            String condition = atributosCategoricos.contains(node.attribute) ?
                    node.attribute + " = " + node.thresholdCategory :
                    node.attribute + " ≤ " + String.format("%.2f", node.threshold);
            System.out.println(indent + "[ATRIBUTO: " + condition + "]");
            System.out.println(indent + "Si es verdadero:");
            printTreeRec(node.left, nivel + 1);
            System.out.println(indent + "Si es falso:");
            printTreeRec(node.right, nivel + 1);
        }
    }

    public TreeNode getRoot() {
        return root;
    }
}