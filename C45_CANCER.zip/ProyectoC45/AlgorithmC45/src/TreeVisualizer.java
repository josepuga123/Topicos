import javax.swing.*;
import java.awt.*;
import java.util.Arrays;
import java.util.List;

public class TreeVisualizer extends JPanel {
    private final TreeNode root;
    private final int nodeWidth = 200;  // Aumentado para mejor visualización
    private final int nodeHeight = 50;  // Aumentado para mejor visualización
    private final int vSpacing = 80;    // Espaciado vertical entre niveles
    private final int hSpacing = 60;    // Espaciado horizontal inicial
    private final List<String> atributosCategoricos = Arrays.asList(
            "Sexo", "Histology", "FamilyHistory", "Menopause",
            "Smoking", "AlcoholConsumption", "HormoneTherapy");

    public TreeVisualizer(TreeNode root) {
        this.root = root;
        setBackground(new Color(245, 245, 245));  // Fondo más suave

        // Calcular dimensiones basadas en la profundidad del árbol
        int depth = getDepth(root);
        System.out.println("Profundidad del árbol: " + depth);

        // Dimensiones más conservadoras para árboles grandes
        int width = Math.min(5000, (int)(Math.pow(2, depth) * (nodeWidth + hSpacing)));
        int height = Math.min(3000, depth * (nodeHeight + vSpacing) + 100);

        setPreferredSize(new Dimension(width, height));
        System.out.println("Tamaño del panel: " + width + "x" + height);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Mejorar calidad de renderizado
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        // Dibujar el árbol centrado
        int startX = getWidth() / 2;
        drawTree(g2d, root, startX, 30, getWidth() / 4);
    }

    private void drawTree(Graphics2D g, TreeNode node, int x, int y, int xOffset) {
        if (node == null) return;

        // Dibujar el nodo actual - VERSIÓN CORREGIDA
        String label = node.isLeaf()
                ? node.label + " (" + String.format("%.1f%%", node.probability * 100) + ")"
                : (atributosCategoricos.contains(node.attribute)
                ? node.attribute + " = " + node.thresholdCategory
                : node.attribute + " ≤ " + String.format("%.2f", node.threshold));


        // Ajustar texto si es muy largo
        if (label.length() > 20) {
            label = label.substring(0, 17) + "...";
        }

        // Dibujar el nodo
        Color nodeColor = node.isLeaf()
                ? new Color(180, 255, 180)  // Verde claro para hojas
                : new Color(180, 180, 255); // Azul claro para nodos de decisión

        g.setColor(nodeColor);
        g.fillRoundRect(x - nodeWidth/2, y, nodeWidth, nodeHeight, 20, 20);

        // Borde del nodo
        g.setColor(Color.DARK_GRAY);
        g.setStroke(new BasicStroke(2));
        g.drawRoundRect(x - nodeWidth/2, y, nodeWidth, nodeHeight, 20, 20);

        // Texto del nodo
        g.setColor(Color.BLACK);
        g.setFont(new Font("Arial", Font.BOLD, 12));
        FontMetrics fm = g.getFontMetrics();

        // Dividir texto si es muy ancho
        if (fm.stringWidth(label) > nodeWidth - 20) {
            String[] parts = splitLabel(label, fm, nodeWidth - 20);
            for (int i = 0; i < parts.length; i++) {
                int textWidth = fm.stringWidth(parts[i]);
                g.drawString(parts[i], x - textWidth/2, y + nodeHeight/2 + (i - parts.length/2) * fm.getHeight());
            }
        } else {
            int textWidth = fm.stringWidth(label);
            g.drawString(label, x - textWidth/2, y + nodeHeight/2 + fm.getAscent()/2 - 2);
        }

        // Dibujar hijos si no es hoja
        if (!node.isLeaf()) {
            int childY = y + nodeHeight + vSpacing;

            // Conexión al hijo izquierdo (Sí)
            if (node.left != null) {
                int leftX = x - xOffset;
                g.setColor(new Color(80, 80, 80));
                g.setStroke(new BasicStroke(1.5f));
                g.drawLine(x, y + nodeHeight, leftX, childY);

                // Etiqueta de la conexión
                g.setColor(new Color(0, 100, 0)); // Verde oscuro para "Sí"
                g.drawString("Sí", x - xOffset/2 - 10, (y + nodeHeight + childY)/2);

                drawTree(g, node.left, leftX, childY, xOffset/2);
            }

            // Conexión al hijo derecho (No)
            if (node.right != null) {
                int rightX = x + xOffset;
                g.setColor(new Color(80, 80, 80));
                g.setStroke(new BasicStroke(1.5f));
                g.drawLine(x, y + nodeHeight, rightX, childY);

                // Etiqueta de la conexión
                g.setColor(new Color(150, 0, 0)); // Rojo oscuro para "No"
                g.drawString("No", x + xOffset/2 + 5, (y + nodeHeight + childY)/2);

                drawTree(g, node.right, rightX, childY, xOffset/2);
            }
        }
    }

    private String[] splitLabel(String label, FontMetrics fm, int maxWidth) {
        // Dividir el texto en partes que quepan en el nodo
        String[] words = label.split(" ");
        StringBuilder currentLine = new StringBuilder();
        java.util.List<String> lines = new java.util.ArrayList<>();

        for (String word : words) {
            if (fm.stringWidth(currentLine + " " + word) <= maxWidth) {
                if (!currentLine.isEmpty()) currentLine.append(" ");
                currentLine.append(word);
            } else {
                lines.add(currentLine.toString());
                currentLine = new StringBuilder(word);
            }
        }
        if (!currentLine.isEmpty()) {
            lines.add(currentLine.toString());
        }
        return lines.toArray(new String[0]);
    }

    private int getDepth(TreeNode node) {
        if (node == null) return 0;
        if (node.isLeaf()) return 1;
        return 1 + Math.max(getDepth(node.left), getDepth(node.right));
    }

    public static void show(TreeNode root) {
        if (root == null) {
            JOptionPane.showMessageDialog(null,
                    "El árbol está vacío o no se pudo generar",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Mostrar estructura en consola para depuración
        System.out.println("=== Estructura del Árbol ===");
        printTreeStructure(root, 0);

        JFrame frame = new JFrame("Árbol de Decisión C4.5 - Visualización");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        TreeVisualizer visualizer = new TreeVisualizer(root);
        JScrollPane scrollPane = new JScrollPane(visualizer);
        scrollPane.setPreferredSize(new Dimension(1200, 800));

        // Configurar barra de herramientas con zoom
        JToolBar toolBar = new JToolBar();
        JButton zoomIn = new JButton("+");
        JButton zoomOut = new JButton("-");
        JButton reset = new JButton("Reset");

        zoomIn.addActionListener(e -> {
            visualizer.setScale(visualizer.getScale() * 1.2);
            visualizer.revalidate();
            visualizer.repaint();
        });

        zoomOut.addActionListener(e -> {
            visualizer.setScale(visualizer.getScale() / 1.2);
            visualizer.revalidate();
            visualizer.repaint();
        });

        reset.addActionListener(e -> {
            visualizer.setScale(1.0);
            visualizer.revalidate();
            visualizer.repaint();
        });

        toolBar.add(zoomIn);
        toolBar.add(zoomOut);
        toolBar.add(reset);

        frame.add(toolBar, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);

        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // Centrar la vista al abrir
        SwingUtilities.invokeLater(() -> {
            JViewport viewport = scrollPane.getViewport();
            Rectangle viewRect = visualizer.getBounds();
            viewport.scrollRectToVisible(new Rectangle(
                    viewRect.width/2 - viewport.getWidth()/2,
                    0,
                    viewport.getWidth(),
                    viewport.getHeight()
            ));
        });
    }

    private static void printTreeStructure(TreeNode node, int level) {
        if (node == null) return;
        String indent = "  ".repeat(level);
        if (node.isLeaf()) {
            System.out.println(indent + "Hoja: " + node.label +
                    " (Prob: " + String.format("%.1f%%", node.probability * 100) + ")");
        } else {
            System.out.println(indent + "Nodo: " + node.attribute +
                    (node.threshold != null ? " ≤ " + node.threshold :
                            " = " + node.thresholdCategory));
            printTreeStructure(node.left, level + 1);
            printTreeStructure(node.right, level + 1);
        }
    }

    // Métodos para soporte de zoom
    private double scale = 1.0;

    public void setScale(double scale) {
        this.scale = Math.max(0.5, Math.min(3.0, scale)); // Limitar rango de zoom
    }

    public double getScale() {
        return scale;
    }

    @Override
    public Dimension getPreferredSize() {
        Dimension size = super.getPreferredSize();
        return new Dimension(
                (int)(size.width * scale),
                (int)(size.height * scale)
        );
    }
}