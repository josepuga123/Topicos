import java.sql.*;
import java.util.*;

public class SQLLoader {
    private final String connectionUrl = "jdbc:sqlserver://localhost:53487;databaseName=C45;encrypt=true;trustServerCertificate=true";
    private final String user = "c45_user";
    private final String password = "C45SecurePass2025";

    public List<Map<String, String>> cargarDatos(String tabla) {
        List<Map<String, String>> datos = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(connectionUrl, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM " + tabla)) {

            ResultSetMetaData metaData = rs.getMetaData();
            int numCols = metaData.getColumnCount();

            while (rs.next()) {
                Map<String, String> fila = new HashMap<>();
                for (int i = 1; i <= numCols; i++) {
                    String col = metaData.getColumnName(i);
                    String val = rs.getString(i);
                    if (!col.equalsIgnoreCase("Id")) {
                        fila.put(col, val);
                    }
                }
                datos.add(fila);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return datos;
    }

    public List<String> obtenerAtributos(String tabla, String columnaClase) {
        List<String> atributos = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(connectionUrl, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT TOP 1 * FROM " + tabla)) {

            ResultSetMetaData metaData = rs.getMetaData();
            int numCols = metaData.getColumnCount();

            for (int i = 1; i <= numCols; i++) {
                String col = metaData.getColumnName(i);
                if (!col.equalsIgnoreCase("Id") && !col.equalsIgnoreCase(columnaClase)) {
                    atributos.add(col);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return atributos;
    }
}