import java.io.*;
import java.util.*;

public class CSVLoader {
    public List<Map<String, String>> loadData(String filePath) {
        List<Map<String, String>> data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String[] headers = br.readLine().split(",");
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                Map<String, String> row = new HashMap<>();
                for (int i = 0; i < headers.length; i++) {
                    if (!headers[i].equalsIgnoreCase("Id")) {
                        row.put(headers[i], values[i]);
                    }
                }
                data.add(row);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return data;
    }

    public List<String> getAttributes(String filePath, String classColumn) {
        List<String> attributes = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String[] headers = br.readLine().split(",");
            for (String header : headers) {
                if (!header.equalsIgnoreCase("Id") && !header.equalsIgnoreCase(classColumn)) {
                    attributes.add(header);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return attributes;
    }
}